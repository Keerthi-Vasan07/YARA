/**
 * API client for YARA online OPeNDAP endpoints.
 *
 * Connects to /api/online/* routes served by the FastAPI backend.
 * Supports SST, SSS, Chlorophyll-a and any future variable in the registry.
 */

const API_BASE = '/api/online';

// ─── Dataset registry types ──────────────────────────────────────────────────

export interface OnlineDatasetConfig {
  variable_key: string;
  dataset_id: string;
  display_name: string;
  units_display: string;
  temporal_resolution: string;
  spatial_resolution_deg: number;
  vmin: number;
  vmax: number;
  description: string;
  source: string;
  provider: string;
  opendap_url: string;
}

export type OnlineDatasetsResponse = Record<string, OnlineDatasetConfig>;

// ─── Metadata types ──────────────────────────────────────────────────────────

export interface OnlineDatasetMetadata {
  variable_key: string;
  dataset_id: string;
  display_name: string;
  units: string;
  source: string;
  provider: string;
  description: string;
  opendap_url: string;
  variable_name: string;
  variable_attrs: Record<string, string>;
  lat_dim: string;
  lon_dim: string;
  time_dim: string;
  n_times: number;
  n_lat: number;
  n_lon: number;
  lat_range: [number, number];
  lon_range: [number, number];
  time_range: [string, string];
  vmin: number;
  vmax: number;
  log_scale: boolean;
  colormap?: string;
  spatial_resolution_deg: number;
}

// ─── Latest time types ───────────────────────────────────────────────────────

export interface OnlineLatestResponse {
  variable: string;
  display_name: string;
  latest_date: string;
  dataset_id: string;
}

// ─── Available times ─────────────────────────────────────────────────────────

export interface OnlineTimesResponse {
  variable: string;
  dataset_id: string;
  count: number;
  start_date: string | null;
  end_date: string | null;
  available_dates: string[];
}

// ─── Point query types ───────────────────────────────────────────────────────

export interface OnlinePointQuery {
  variable_key: string;
  display_name: string;
  units_display: string;
  date_requested: string;
  date_matched: string;
  requested_lat: number;
  requested_lon: number;
  matched_lat: number | null;
  matched_lon: number | null;
  value: number | null;
  message: string | null;
  source: string;
  dataset_id: string;
}

// ─────────────────────────────────────────────────────────────────────────────
//  API functions
// ─────────────────────────────────────────────────────────────────────────────

async function _fetchJson<T>(url: string): Promise<T> {
  const res = await fetch(url);
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail || body.message || detail;
    } catch {
      // ignore
    }
    throw new Error(`Online API error ${res.status}: ${detail}`);
  }
  return res.json() as Promise<T>;
}

/** List all registered online variables. */
export async function fetchOnlineDatasets(): Promise<OnlineDatasetsResponse> {
  return _fetchJson<OnlineDatasetsResponse>(`${API_BASE}/datasets`);
}

/** Get full metadata for a variable (cached on backend after first call). */
export async function fetchOnlineMetadata(variable: string): Promise<OnlineDatasetMetadata> {
  return _fetchJson<OnlineDatasetMetadata>(`${API_BASE}/${variable}/metadata`);
}

/** Get the latest available date in the remote dataset (NOT the server clock). */
export async function fetchOnlineLatest(variable: string): Promise<OnlineLatestResponse> {
  return _fetchJson<OnlineLatestResponse>(`${API_BASE}/${variable}/latest`);
}

/** Get all available dates for a variable. */
export async function fetchOnlineTimes(variable: string): Promise<OnlineTimesResponse> {
  return _fetchJson<OnlineTimesResponse>(`${API_BASE}/${variable}/times`);
}

export interface OnlineFrameResponse {
  blobUrl: string;
  matchedDate: string;
  variable: string;
  datasetId: string;
  bounds: {
    west: number;
    south: number;
    east: number;
    north: number;
  };
  width?: number;
  height?: number;
}

/**
 * Get the URL of the rendered PNG frame for a variable and date.
 */
export function getOnlineFrameUrl(
  variable: string,
  date: string,
  options?: {
    latMin?: number;
    latMax?: number;
    lonMin?: number;
    lonMax?: number;
    maxPixels?: number;
  }
): string {
  const {
    latMin = -90,
    latMax = 90,
    lonMin = -180,
    lonMax = 180,
    maxPixels = 2048,
  } = options ?? {};

  const params = new URLSearchParams({
    date,
    lat_min: String(latMin),
    lat_max: String(latMax),
    lon_min: String(lonMin),
    lon_max: String(lonMax),
    max_pixels: String(maxPixels),
  });

  return `${API_BASE}/${variable}/frame.png?${params.toString()}`;
}

/**
 * Fetch the online PNG frame and extract exact geospatial bounds from response headers.
 */
export async function fetchOnlineFrame(
  variable: string,
  date: string,
  options?: {
    latMin?: number;
    latMax?: number;
    lonMin?: number;
    lonMax?: number;
    maxPixels?: number;
  },
  signal?: AbortSignal
): Promise<OnlineFrameResponse> {
  const url = getOnlineFrameUrl(variable, date, options);
  const res = await fetch(url, { signal });

  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail || body.message || detail;
    } catch {
      // ignore
    }
    throw new Error(`Frame fetch error ${res.status}: ${detail}`);
  }

  const blob = await res.blob();
  const blobUrl = URL.createObjectURL(blob);

  const matchedDate = res.headers.get('X-Date-Matched') || date;
  const datasetId = res.headers.get('X-Dataset-Id') || '';

  const westStr = res.headers.get('X-Bounds-West');
  const southStr = res.headers.get('X-Bounds-South');
  const eastStr = res.headers.get('X-Bounds-East');
  const northStr = res.headers.get('X-Bounds-North');

  const widthStr = res.headers.get('X-Raster-Width');
  const heightStr = res.headers.get('X-Raster-Height');

  const defaultWest = options?.lonMin ?? -180;
  const defaultSouth = options?.latMin ?? -90;
  const defaultEast = options?.lonMax ?? 180;
  const defaultNorth = options?.latMax ?? 90;

  const bounds = {
    west: westStr !== null ? parseFloat(westStr) : defaultWest,
    south: southStr !== null ? parseFloat(southStr) : defaultSouth,
    east: eastStr !== null ? parseFloat(eastStr) : defaultEast,
    north: northStr !== null ? parseFloat(northStr) : defaultNorth,
  };

  return {
    blobUrl,
    matchedDate,
    variable,
    datasetId,
    bounds,
    width: widthStr !== null ? parseInt(widthStr, 10) : undefined,
    height: heightStr !== null ? parseInt(heightStr, 10) : undefined,
  };
}

/**
 * Query the value of a variable at a specific lon/lat for a given date.
 * Pass date = 'latest' to use the most recent available observation.
 */
export async function fetchOnlinePoint(
  variable: string,
  date: string,
  lon: number,
  lat: number
): Promise<OnlinePointQuery> {
  const params = new URLSearchParams({
    date,
    lon: String(lon),
    lat: String(lat),
  });
  return _fetchJson<OnlinePointQuery>(`${API_BASE}/${variable}/point?${params.toString()}`);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Dynamic helpers (no hardcoded variable list)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Derive display defaults for a variable from the backend dataset config.
 * Use this instead of the old ONLINE_VARIABLE_DEFAULTS constant.
 */
export function getVariableDefaults(
  cfg: OnlineDatasetConfig | undefined
): { vmin: number; vmax: number; units: string } {
  if (!cfg) return { vmin: 0, vmax: 1, units: '' };
  return {
    vmin: cfg.vmin,
    vmax: cfg.vmax,
    units: cfg.units_display,
  };
}
