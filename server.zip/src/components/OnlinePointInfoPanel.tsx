import { useRef, useState, useCallback, useEffect } from 'react';
import { createPortal } from 'react-dom';
import {
  Box, Typography, Stack, IconButton, Chip, alpha, CircularProgress, Divider,
} from '@mui/material';
import { Close, Place, CalendarMonth, DragIndicator } from '@mui/icons-material';
import { OnlinePointQuery } from '../api/onlineApi';

// ─── Props ───────────────────────────────────────────────────────────────────

interface OnlinePointInfoPanelProps {
  data: OnlinePointQuery | null;
  loading: boolean;
  onClose: () => void;
  screenPosition?: { x: number; y: number } | null;
}

// ─── Accent colours per variable ─────────────────────────────────────────────

function varAccent(variable: string): string {
  switch (variable) {
    case 'sst': return '#ff7043';
    case 'sss': return '#29b6f6';
    case 'chlorophyll': return '#66bb6a';
    default: return '#6EF2FC';
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Panel
// ─────────────────────────────────────────────────────────────────────────────

export function OnlinePointInfoPanel({ data, loading, onClose, screenPosition }: OnlinePointInfoPanelProps) {
  const panelRef = useRef<HTMLDivElement>(null);
  const initialRight = 80;
  const initialTop = 20;
  const panelWidth = 300;

  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef({ x: 0, y: 0, posX: 0, posY: 0 });

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
    dragStartRef.current = { x: e.clientX, y: e.clientY, posX: position.x, posY: position.y };
  }, [position]);

  useEffect(() => {
    if (!isDragging) return;
    const onMove = (e: MouseEvent) => {
      setPosition({
        x: dragStartRef.current.posX + (e.clientX - dragStartRef.current.x),
        y: dragStartRef.current.posY + (e.clientY - dragStartRef.current.y),
      });
    };
    const onUp = () => setIsDragging(false);
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    return () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };
  }, [isDragging]);

  if (!data && !loading) return null;

  const accent = data ? varAccent(data.variable_key) : '#6EF2FC';
  const panelTop = initialTop + position.y;
  const panelRight = initialRight - position.x;
  const panelLeftEdge = typeof window !== 'undefined' ? window.innerWidth - panelRight - panelWidth : 0;
  const panelConnectionY = panelTop + 40;

  // Connection line via portal
  const connectionLine = screenPosition && (data || loading) ? createPortal(
    <svg
      style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', pointerEvents: 'none', zIndex: 9999, overflow: 'visible' }}
    >
      <line
        x1={screenPosition.x} y1={screenPosition.y}
        x2={panelLeftEdge} y2={panelConnectionY}
        stroke={`${alpha(accent, 0.6)}`}
        strokeWidth="1.5" strokeDasharray="5,3" strokeLinecap="round"
      />
      <circle cx={screenPosition.x} cy={screenPosition.y} r="5" fill={accent} stroke="rgba(0,0,0,0.5)" strokeWidth="1" />
      <circle cx={panelLeftEdge} cy={panelConnectionY} r="3" fill={accent} />
    </svg>,
    document.body
  ) : null;

  return (
    <>
      {connectionLine}
      <Box
        ref={panelRef}
        sx={{
          position: 'absolute',
          top: panelTop,
          right: panelRight,
          width: panelWidth,
          bgcolor: 'rgba(6, 10, 18, 0.92)',
          backdropFilter: 'blur(20px)',
          border: `1px solid ${alpha(accent, 0.35)}`,
          borderRadius: 0,
          overflow: 'hidden',
          zIndex: 1100,
          boxShadow: `0 8px 32px rgba(0,0,0,0.5), 0 0 0 1px rgba(0,0,0,0.2)`,
        }}
      >
        {/* Top accent bar */}
        <Box sx={{ height: 2, background: `linear-gradient(90deg, transparent, ${accent}, transparent)`, opacity: 0.8 }} />

        {/* Header */}
        <Box
          sx={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            px: 2, py: 1.25,
            borderBottom: `1px solid ${alpha(accent, 0.15)}`,
            cursor: isDragging ? 'grabbing' : 'grab',
          }}
          onMouseDown={handleMouseDown}
        >
          <Stack direction="row" spacing={0.75} alignItems="center">
            <DragIndicator sx={{ fontSize: 15, color: 'rgba(255,255,255,0.3)' }} />
            <Typography variant="subtitle2" fontWeight={700} sx={{ color: accent, fontSize: '0.78rem' }}>
              {data?.display_name ?? 'Ocean Data'}
            </Typography>
          </Stack>
          <IconButton size="small" onClick={onClose} sx={{ color: 'rgba(255,255,255,0.4)', '&:hover': { color: 'white' } }}>
            <Close fontSize="small" />
          </IconButton>
        </Box>

        {/* Content */}
        <Box sx={{ p: 2 }}>
          {loading ? (
            <Stack alignItems="center" spacing={2} py={3}>
              <CircularProgress size={32} sx={{ color: accent }} />
              <Typography variant="body2" color="text.secondary">Querying ocean data…</Typography>
            </Stack>
          ) : data ? (
            <Stack spacing={1.5}>
              {/* Value display */}
              {data.value !== null ? (
                <Box
                  sx={{
                    p: 1.5, borderRadius: 0,
                    bgcolor: alpha(accent, 0.09),
                    border: `1px solid ${alpha(accent, 0.25)}`,
                  }}
                >
                  <Stack direction="row" alignItems="baseline" spacing={1}>
                    <Typography
                      variant="h3"
                      fontWeight={900}
                      sx={{
                        color: accent, lineHeight: 1, letterSpacing: '-0.02em',
                        textShadow: `0 0 16px ${alpha(accent, 0.6)}`,
                        filter: 'brightness(1.2)',
                      }}
                    >
                      {data.value.toFixed(
                        data.variable_key === 'chlorophyll' ? 4 : 2
                      )}
                    </Typography>
                    <Typography variant="body1" sx={{ color: alpha(accent, 0.75), fontWeight: 500 }}>
                      {data.units_display}
                    </Typography>
                  </Stack>
                  <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.65rem' }}>
                    {data.display_name}
                  </Typography>
                </Box>
              ) : (
                <Box sx={{ py: 2, textAlign: 'center' }}>
                  <Typography variant="body2" color="text.secondary">
                    {data.message ?? 'No data at this location'}
                  </Typography>
                  <Typography variant="caption" color="text.disabled" sx={{ display: 'block', mt: 0.5 }}>
                    Land, cloud mask, or outside coverage
                  </Typography>
                </Box>
              )}

              <Divider sx={{ borderColor: alpha(accent, 0.1) }} />

              {/* Location */}
              <Box>
                <Stack direction="row" spacing={0.5} alignItems="center" mb={0.75}>
                  <Place sx={{ fontSize: 13, color: 'text.secondary' }} />
                  <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.62rem', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                    Location
                  </Typography>
                </Stack>
                <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0.75 }}>
                  {[
                    ['Requested', `${data.requested_lat?.toFixed(4)}°N, ${data.requested_lon?.toFixed(4)}°E`],
                    ['Matched', data.matched_lat != null ? `${data.matched_lat?.toFixed(4)}°N, ${data.matched_lon?.toFixed(4)}°E` : '—'],
                  ].map(([label, val]) => (
                    <Box key={label} sx={{ p: 0.75, bgcolor: 'rgba(255,255,255,0.04)', borderRadius: 0.5 }}>
                      <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.35)', fontSize: '0.58rem', display: 'block' }}>{label}</Typography>
                      <Typography variant="caption" sx={{ fontFamily: 'monospace', fontSize: '0.65rem', color: 'rgba(255,255,255,0.75)' }}>{val}</Typography>
                    </Box>
                  ))}
                </Box>
              </Box>

              {/* Date */}
              <Stack direction="row" spacing={0.75} alignItems="center">
                <CalendarMonth sx={{ fontSize: 13, color: 'text.secondary' }} />
                <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.55)', fontSize: '0.7rem' }}>
                  {data.date_matched}
                  {data.date_matched !== data.date_requested && (
                    <Typography component="span" variant="caption" sx={{ color: 'rgba(255,255,255,0.35)', ml: 0.5, fontSize: '0.6rem' }}>
                      (requested {data.date_requested})
                    </Typography>
                  )}
                </Typography>
              </Stack>

              {/* Source chips */}
              <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap>
                <Chip
                  label={data.source}
                  size="small"
                  variant="outlined"
                  sx={{ fontSize: '0.6rem', borderColor: alpha(accent, 0.3), color: 'rgba(255,255,255,0.5)' }}
                />
                <Chip
                  label={data.dataset_id}
                  size="small"
                  variant="outlined"
                  sx={{ fontSize: '0.6rem', borderColor: alpha(accent, 0.3), color: 'rgba(255,255,255,0.5)' }}
                />
              </Stack>
            </Stack>
          ) : null}
        </Box>
      </Box>
    </>
  );
}
