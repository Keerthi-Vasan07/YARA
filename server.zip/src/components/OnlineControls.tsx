import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Box, Typography, Stack, alpha, CircularProgress,
  Tooltip, Divider, LinearProgress, MenuItem, Select,
  SelectChangeEvent,
} from '@mui/material';
import {
  CalendarMonth, CheckCircle,
  ErrorOutline, CloudOff, Satellite,
} from '@mui/icons-material';
import {
  fetchOnlineDatasets, fetchOnlineLatest, fetchOnlineMetadata, fetchOnlineTimes,
  OnlineDatasetConfig, OnlineDatasetsResponse, OnlineDatasetMetadata,
  getVariableDefaults,
} from '../api/onlineApi';

// ─── Types ───────────────────────────────────────────────────────────────────

/** Any variable key string returned by the backend */
export type OnlineVariableKey = string;

export interface OnlineState {
  variable: OnlineVariableKey;
  /** 'latest' or a specific YYYY-MM-DD date */
  date: string;
  /** The actual matched date from the remote dataset */
  resolvedDate: string | null;
  /** List of available observation dates for the active variable */
  availableDates: string[];
  /** Metadata from the backend */
  metadata: OnlineDatasetMetadata | null;
  status: 'idle' | 'loading' | 'ready' | 'error';
  error: string | null;
  /** Dataset registry fetched from GET /api/online/datasets */
  registry: OnlineDatasetsResponse | null;
}

interface OnlineControlsProps {
  /** Current online state — controlled externally */
  state: OnlineState;
  /** Called when the user changes variable or date */
  onChange: (next: Partial<OnlineState>) => void;
  /** Whether the online frame is currently loading in the globe */
  frameLoading?: boolean;
}

// ─── Variable colour accent ───────────────────────────────────────────────────

function varAccent(variable: string): string {
  // Assign visually-distinct colours based on variable category
  switch (variable) {
    case 'thetao':
    case 'bottomT':   return '#ff7043'; // Temperature → warm orange
    case 'so':         return '#29b6f6'; // Salinity → blue
    case 'uo':
    case 'vo':         return '#ab47bc'; // Current velocity → purple
    case 'zos':        return '#26a69a'; // Sea surface height → teal
    case 'mlotst':     return '#ffa726'; // Mixed layer → amber
    case 'siconc':
    case 'sithick':    return '#78909c'; // Sea ice → blue-grey
    case 'usi':
    case 'vsi':        return '#7e57c2'; // Ice velocity → deep purple
    default:           return '#6EF2FC'; // Fallback → cyan
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Component
// ─────────────────────────────────────────────────────────────────────────────

export function OnlineControls({ state, onChange, frameLoading = false }: OnlineControlsProps) {
  const { variable, date, availableDates = [], metadata, status, error, registry } = state;
  const [latestDate, setLatestDate] = useState<string | null>(null);
  const [latestLoading, setLatestLoading] = useState(false);
  const [registryLoading, setRegistryLoading] = useState(false);
  const initRef = useRef(false);

  const accent = varAccent(variable);
  const currentConfig: OnlineDatasetConfig | undefined = registry?.[variable];
  const defaults = getVariableDefaults(currentConfig);

  // ── Bootstrap: load dataset registry on mount ────────────────────────────
  useEffect(() => {
    if (initRef.current) return;
    initRef.current = true;

    setRegistryLoading(true);
    fetchOnlineDatasets()
      .then((datasets) => {
        const keys = Object.keys(datasets);
        if (keys.length === 0) {
          onChange({ registry: datasets, status: 'error', error: 'No online variables returned by backend.' });
          return;
        }

        // Pick first variable as default if current is not in the registry
        const firstVar = keys.includes(variable) ? variable : keys[0];
        onChange({
          registry: datasets,
          variable: firstVar,
          status: 'loading',
        });
      })
      .catch((err) => {
        console.error('[OnlineControls] Failed to load datasets:', err);
        onChange({ status: 'error', error: `Failed to load dataset registry: ${err}` });
      })
      .finally(() => setRegistryLoading(false));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Fetch latest date, available times + metadata when variable changes ──
  useEffect(() => {
    if (!registry || !variable) return;

    let cancelled = false;
    setLatestLoading(true);

    // Fetch latest date, metadata, and all available times in parallel
    Promise.all([
      fetchOnlineLatest(variable),
      fetchOnlineMetadata(variable),
      fetchOnlineTimes(variable).catch(() => ({ available_dates: [] as string[] })),
    ])
      .then(([latestRes, metadataRes, timesRes]) => {
        if (cancelled) return;
        const fetchedDates: string[] = (timesRes.available_dates || []) as string[];
        setLatestDate(latestRes.latest_date);

        // Preserve current date if present in newly fetched dates, otherwise default to latest
        let nextDate = date;
        if (date !== 'latest' && fetchedDates.length > 0 && !fetchedDates.includes(date)) {
          nextDate = 'latest';
        }

        onChange({
          availableDates: fetchedDates,
          date: nextDate,
          resolvedDate: nextDate === 'latest' ? latestRes.latest_date : nextDate,
          metadata: metadataRes,
          status: 'ready',
          error: null,
        });
      })
      .catch((err) => {
        if (cancelled) return;
        console.error('[OnlineControls] Failed to fetch latest/metadata/times:', err);
        onChange({ status: 'error', error: String(err) });
      })
      .finally(() => {
        if (!cancelled) setLatestLoading(false);
      });

    return () => { cancelled = true; };
  }, [variable, registry]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleVariableChange = useCallback((event: SelectChangeEvent<string>) => {
    const newVar = event.target.value;
    if (!newVar || newVar === variable) return;
    onChange({
      variable: newVar,
      date: 'latest',
      resolvedDate: null,
      metadata: null,
      status: 'loading',
      error: null,
    });
  }, [variable, onChange]);

  const isLoading = status === 'loading' || frameLoading || latestLoading || registryLoading;

  // Build sorted variable keys from registry
  const variableKeys = registry ? Object.keys(registry) : [];

  return (
    <Box
      sx={{
        position: 'absolute',
        top: 80,
        left: 16,
        width: 280,
        bgcolor: 'rgba(6, 10, 18, 0.88)',
        backdropFilter: 'blur(20px)',
        borderRadius: 0,
        border: `1px solid ${alpha(accent, 0.35)}`,
        overflow: 'hidden',
        zIndex: 1000,
        boxShadow: `0 8px 32px rgba(0,0,0,0.45), 0 0 0 1px rgba(0,0,0,0.2), inset 0 1px 0 ${alpha(accent, 0.15)}`,
      }}
    >
      {/* Top accent bar */}
      <Box
        sx={{
          height: 2,
          background: `linear-gradient(90deg, transparent, ${accent}, transparent)`,
          opacity: 0.7,
        }}
      />

      {/* Header */}
      <Box sx={{ px: 2, pt: 1.5, pb: 1, borderBottom: `1px solid ${alpha(accent, 0.15)}` }}>
        <Stack direction="row" alignItems="center" spacing={1}>
          <Satellite sx={{ fontSize: 14, color: accent }} />
          <Typography
            variant="caption"
            sx={{
              fontWeight: 700,
              letterSpacing: '0.12em',
              textTransform: 'uppercase',
              color: alpha(accent, 0.9),
              fontSize: '0.65rem',
            }}
          >
            Online Ocean Data
          </Typography>
          <Box sx={{ flexGrow: 1 }} />
          {isLoading ? (
            <CircularProgress size={10} sx={{ color: accent }} />
          ) : status === 'ready' ? (
            <CheckCircle sx={{ fontSize: 12, color: '#66bb6a' }} />
          ) : status === 'error' ? (
            <ErrorOutline sx={{ fontSize: 12, color: '#ef5350' }} />
          ) : null}
        </Stack>
      </Box>

      {/* Loading progress bar */}
      {isLoading && (
        <LinearProgress
          sx={{
            height: 1,
            bgcolor: alpha(accent, 0.1),
            '& .MuiLinearProgress-bar': { bgcolor: accent },
          }}
        />
      )}

      <Box sx={{ px: 2, py: 1.5 }}>
        {/* Variable selector */}
        <Typography
          variant="caption"
          sx={{ color: 'rgba(255,255,255,0.45)', fontSize: '0.62rem', letterSpacing: '0.08em', textTransform: 'uppercase' }}
        >
          Variable
        </Typography>

        <Select
          value={variable}
          onChange={handleVariableChange}
          size="small"
          fullWidth
          disabled={registryLoading || variableKeys.length === 0}
          sx={{
            mt: 0.75,
            mb: 0.5,
            color: accent,
            fontWeight: 600,
            fontSize: '0.72rem',
            bgcolor: alpha(accent, 0.07),
            border: `1px solid ${alpha(accent, 0.25)}`,
            '& .MuiOutlinedInput-notchedOutline': { border: 'none' },
            '& .MuiSelect-icon': { color: alpha(accent, 0.5) },
            '&:hover': { bgcolor: alpha(accent, 0.12) },
            '& .MuiSelect-select': { py: 0.75 },
          }}
          MenuProps={{
            PaperProps: {
              sx: {
                bgcolor: 'rgba(6, 10, 18, 0.96)',
                backdropFilter: 'blur(20px)',
                border: `1px solid ${alpha(accent, 0.3)}`,
                maxHeight: 320,
                '& .MuiMenuItem-root': {
                  fontSize: '0.72rem',
                  color: 'rgba(255,255,255,0.75)',
                  '&:hover': { bgcolor: alpha(accent, 0.12) },
                  '&.Mui-selected': { bgcolor: alpha(accent, 0.18), color: accent },
                },
              },
            },
          }}
        >
          {variableKeys.map((key) => {
            const cfg = registry![key];
            return (
              <MenuItem key={key} value={key}>
                <Stack direction="row" spacing={1} alignItems="center" sx={{ width: '100%' }}>
                  <Box
                    sx={{
                      width: 8, height: 8, borderRadius: '50%',
                      bgcolor: varAccent(key), flexShrink: 0,
                    }}
                  />
                  <Box sx={{ flex: 1, overflow: 'hidden' }}>
                    <Typography sx={{ fontSize: '0.72rem', fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {cfg.display_name}
                    </Typography>
                    <Typography sx={{ fontSize: '0.55rem', color: 'rgba(255,255,255,0.35)' }}>
                      {key} · {cfg.units_display}
                    </Typography>
                  </Box>
                </Stack>
              </MenuItem>
            );
          })}
        </Select>

        <Divider sx={{ my: 1.5, borderColor: alpha(accent, 0.12) }} />

        {/* Date selector */}
        <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 0.5 }}>
          <CalendarMonth sx={{ fontSize: 13, color: alpha(accent, 0.7) }} />
          <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.45)', fontSize: '0.62rem', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
            Date ({availableDates.length > 0 ? `${availableDates.length} dates` : 'Latest'})
          </Typography>
        </Stack>

        <Select
          value={date}
          onChange={(e) => {
            const selectedVal = e.target.value;
            onChange({
              date: selectedVal,
              resolvedDate: selectedVal === 'latest' ? latestDate : selectedVal,
            });
          }}
          size="small"
          fullWidth
          sx={{
            mt: 0.5,
            mb: 0.5,
            color: 'rgba(255,255,255,0.9)',
            fontWeight: 500,
            fontSize: '0.72rem',
            fontFamily: 'monospace',
            bgcolor: alpha(accent, 0.07),
            border: `1px solid ${alpha(accent, 0.25)}`,
            '& .MuiOutlinedInput-notchedOutline': { border: 'none' },
            '& .MuiSelect-icon': { color: alpha(accent, 0.5) },
            '&:hover': { bgcolor: alpha(accent, 0.12) },
            '& .MuiSelect-select': { py: 0.75 },
          }}
          MenuProps={{
            PaperProps: {
              sx: {
                bgcolor: 'rgba(6, 10, 18, 0.96)',
                backdropFilter: 'blur(20px)',
                border: `1px solid ${alpha(accent, 0.3)}`,
                maxHeight: 280,
                '& .MuiMenuItem-root': {
                  fontSize: '0.72rem',
                  fontFamily: 'monospace',
                  color: 'rgba(255,255,255,0.75)',
                  '&:hover': { bgcolor: alpha(accent, 0.12) },
                  '&.Mui-selected': { bgcolor: alpha(accent, 0.18), color: accent },
                },
              },
            },
          }}
        >
          <MenuItem value="latest">
            Latest Available ({latestDate ?? '…'})
          </MenuItem>
          {availableDates.map((d) => (
            <MenuItem key={d} value={d}>
              {d}
            </MenuItem>
          ))}
        </Select>

        <Divider sx={{ my: 1.5, borderColor: alpha(accent, 0.12) }} />

        {/* Status row */}
        <Stack spacing={0.75}>
          {/* Variable display name */}
          <Stack direction="row" justifyContent="space-between" alignItems="center">
            <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.35)', fontSize: '0.62rem' }}>
              Variable
            </Typography>
            <Tooltip title={currentConfig?.description ?? ''} placement="left" arrow>
              <Typography variant="caption" sx={{ color: accent, fontSize: '0.62rem', fontWeight: 600, maxWidth: 160, textAlign: 'right', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', cursor: 'help' }}>
                {currentConfig?.display_name ?? variable}
              </Typography>
            </Tooltip>
          </Stack>

          {/* Dataset */}
          <Stack direction="row" justifyContent="space-between" alignItems="center">
            <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.35)', fontSize: '0.62rem' }}>
              Dataset
            </Typography>
            <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.65)', fontSize: '0.62rem', maxWidth: 160, textAlign: 'right', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {metadata?.dataset_id ?? currentConfig?.dataset_id ?? '—'}
            </Typography>
          </Stack>

          {/* Units */}
          <Stack direction="row" justifyContent="space-between" alignItems="center">
            <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.35)', fontSize: '0.62rem' }}>
              Units
            </Typography>
            <Typography variant="caption" sx={{ color: accent, fontSize: '0.7rem', fontWeight: 600 }}>
              {metadata?.units ?? defaults.units ?? '—'}
            </Typography>
          </Stack>

          {/* Resolution */}
          {(metadata || currentConfig) && (
            <Stack direction="row" justifyContent="space-between" alignItems="center">
              <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.35)', fontSize: '0.62rem' }}>
                Resolution
              </Typography>
              <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.65)', fontSize: '0.62rem' }}>
                {(metadata?.spatial_resolution_deg ?? currentConfig?.spatial_resolution_deg)}°
              </Typography>
            </Stack>
          )}

          {/* Provider */}
          {(metadata || currentConfig) && (
            <Stack direction="row" justifyContent="space-between" alignItems="center">
              <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.35)', fontSize: '0.62rem' }}>
                Source
              </Typography>
              <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.55)', fontSize: '0.6rem', maxWidth: 160, textAlign: 'right', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {metadata?.provider ?? currentConfig?.provider ?? '—'}
              </Typography>
            </Stack>
          )}

          {/* Value range */}
          <Stack direction="row" justifyContent="space-between" alignItems="center">
            <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.35)', fontSize: '0.62rem' }}>
              Range
            </Typography>
            <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.55)', fontSize: '0.62rem', fontFamily: 'monospace' }}>
              {defaults.vmin} – {defaults.vmax} {defaults.units}
            </Typography>
          </Stack>
        </Stack>

        {/* Error display */}
        {status === 'error' && error && (
          <Box sx={{ mt: 1.5, p: 1, bgcolor: 'rgba(239,83,80,0.08)', border: '1px solid rgba(239,83,80,0.25)', borderRadius: 1 }}>
            <Stack direction="row" spacing={0.5} alignItems="flex-start">
              <CloudOff sx={{ fontSize: 13, color: '#ef5350', mt: 0.1, flexShrink: 0 }} />
              <Typography variant="caption" sx={{ color: '#ef9a9a', fontSize: '0.62rem', lineHeight: 1.4 }}>
                {error}
              </Typography>
            </Stack>
          </Box>
        )}

        {/* Status indicator */}
        {status === 'ready' && (
          <Stack direction="row" spacing={0.5} alignItems="center" sx={{ mt: 1 }}>
            <Box sx={{ width: 6, height: 6, borderRadius: '50%', bgcolor: '#66bb6a', boxShadow: '0 0 6px #66bb6a' }} />
            <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.35)', fontSize: '0.6rem' }}>
              Online data loaded
            </Typography>
          </Stack>
        )}
      </Box>
    </Box>
  );
}
