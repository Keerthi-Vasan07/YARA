"""
Generic Online / OPeNDAP API endpoints for YARA.

Supports SST, SSS, and Chlorophyll-a (and any future variable in the registry)
via NOAA/NASA ERDDAP OPeNDAP using xarray + pydap.

Routes:
    GET /api/online/datasets                     — list all registered variables
    GET /api/online/{variable}/metadata          — dataset metadata + dimension info
    GET /api/online/{variable}/latest            — latest available timestamp
    GET /api/online/{variable}/times             — all available dates
    GET /api/online/{variable}/frame.png         — rendered PNG frame for a date
    GET /api/online/{variable}/point             — point query (click-to-query)
"""

import asyncio
import logging
from concurrent.futures import ThreadPoolExecutor

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import Response

from server.data_sources.online_registry import ONLINE_DATASETS, get_dataset_config
from server.data_sources.erddap_opendap import (
    HAS_XARRAY,
    HAS_COPERNICUS,
    inspect_dataset_metadata,
    get_latest_time,
    get_available_times,
    render_to_png,
    query_point,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/online", tags=["Online / OPeNDAP"])

# Thread pool for blocking IO (OPeNDAP network calls)
_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="online")


def _require_xarray():
    if not HAS_XARRAY:
        raise HTTPException(
            status_code=503,
            detail="xarray is not installed."
        )

    if not HAS_COPERNICUS:
        raise HTTPException(
            status_code=503,
            detail="copernicusmarine is not installed."
        )


def _get_config(variable: str):
    try:
        return get_dataset_config(variable)
    except KeyError as exc:
        raise HTTPException(
            status_code=404,
            detail=f"Unknown online variable '{variable}'. "
                   f"Available: {list(ONLINE_DATASETS.keys())}",
        ) from exc


# ─────────────────────────────────────────────────────────────────────────────
#  Dataset registry list
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/datasets")
async def list_datasets():
    """List all registered online variables with their metadata."""
    result = {}
    for key, cfg in ONLINE_DATASETS.items():
        result[key] = {
            "variable_key": key,
            "dataset_id": cfg["dataset_id"],
            "display_name": cfg["display_name"],
            "units_display": cfg.get("units_display", cfg["units"]),
            "temporal_resolution": cfg["temporal_resolution"],
            "spatial_resolution_deg": cfg["spatial_resolution_deg"],
            "vmin": cfg["vmin"],
            "vmax": cfg["vmax"],
            "description": cfg["description"],
            "source": cfg["source"],
            "provider": cfg["provider"],
            "opendap_url": cfg.get("url") or cfg.get("opendap_url"),
        }
    return result


# ─────────────────────────────────────────────────────────────────────────────
#  Metadata
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/{variable}/metadata")
async def get_metadata(variable: str):
    """
    Return full dataset metadata for a registered variable.
    Opens the remote OPeNDAP dataset and inspects its dimensions.
    Result is cached after first call.
    """
    _require_xarray()
    cfg = _get_config(variable)
    loop = asyncio.get_event_loop()
    try:
        meta = await loop.run_in_executor(
            _executor, inspect_dataset_metadata, variable, cfg
        )
        return meta
    except ConnectionError as exc:
        logger.error(f"[ONLINE] Cannot connect to OPeNDAP for '{variable}': {exc}")
        raise HTTPException(
            status_code=502,
            detail=f"Unable to retrieve online dataset: {exc}",
        )
    except Exception as exc:
        logger.error(f"[ONLINE] Metadata error for '{variable}': {exc}", exc_info=True)
        raise HTTPException(
            status_code=502,
            detail=f"Unable to retrieve metadata for '{variable}': {exc}",
        )


# ─────────────────────────────────────────────────────────────────────────────
#  Latest timestamp
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/{variable}/latest")
async def get_latest(variable: str):
    """
    Return the latest available date in the remote dataset.
    This uses the actual dataset time axis — NOT the server clock.
    """
    _require_xarray()
    cfg = _get_config(variable)
    loop = asyncio.get_event_loop()
    try:
        latest = await loop.run_in_executor(
            _executor, get_latest_time, variable, cfg
        )
        return {
            "variable": variable,
            "display_name": cfg["display_name"],
            "latest_date": latest,
            "dataset_id": cfg["dataset_id"],
        }
    except ConnectionError as exc:
        raise HTTPException(status_code=502, detail=f"Unable to retrieve online dataset: {exc}")
    except Exception as exc:
        logger.error(f"[ONLINE] Latest time error for '{variable}': {exc}", exc_info=True)
        raise HTTPException(
            status_code=502,
            detail=f"Unable to determine latest time for '{variable}': {exc}",
        )


# ─────────────────────────────────────────────────────────────────────────────
#  Available times
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/{variable}/times")
async def get_times(variable: str):
    """
    Return the list of available dates for a variable.
    Only reads the 1-D time dimension — does not download any data values.
    """
    _require_xarray()
    cfg = _get_config(variable)
    loop = asyncio.get_event_loop()
    try:
        dates = await loop.run_in_executor(
            _executor, get_available_times, variable, cfg
        )
        return {
            "variable": variable,
            "dataset_id": cfg["dataset_id"],
            "count": len(dates),
            "start_date": dates[0] if dates else None,
            "end_date": dates[-1] if dates else None,
            "available_dates": dates,
        }
    except ConnectionError as exc:
        raise HTTPException(status_code=502, detail=f"Unable to retrieve online dataset: {exc}")
    except Exception as exc:
        logger.error(f"[ONLINE] Times error for '{variable}': {exc}", exc_info=True)
        raise HTTPException(
            status_code=502,
            detail=f"Unable to retrieve available times for '{variable}': {exc}",
        )


# ─────────────────────────────────────────────────────────────────────────────
#  PNG frame rendering
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/{variable}/frame.png")
async def get_frame_png(
    variable: str,
    date: str = Query(..., description="Date YYYY-MM-DD or 'latest'"),
    lat_min: float = Query(-90.0, ge=-90, le=90),
    lat_max: float = Query(90.0, ge=-90, le=90),
    lon_min: float = Query(-180.0, ge=-180, le=180),
    lon_max: float = Query(180.0, ge=-180, le=180),
    max_pixels: int = Query(2048, ge=128, le=4096),
):
    """
    Render the variable as a transparent RGBA PNG for the given date and bounds.

    The returned headers contain exact outer cell-edge bounds:
    X-Bounds-West, X-Bounds-South, X-Bounds-East, X-Bounds-North.
    """
    _require_xarray()
    cfg = _get_config(variable)
    loop = asyncio.get_event_loop()

    # Resolve 'latest'
    if date == "latest":
        try:
            date = await loop.run_in_executor(_executor, get_latest_time, variable, cfg)
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Cannot determine latest time: {exc}")

    # Validate date format
    try:
        parts = date.split("-")
        assert len(parts) == 3 and all(p.isdigit() for p in parts), "bad format"
    except (AssertionError, Exception):
        raise HTTPException(status_code=400, detail=f"Invalid date '{date}'. Use YYYY-MM-DD or 'latest'.")

    try:
        png_bytes, matched, bounds = await loop.run_in_executor(
            _executor,
            render_to_png,
            variable, cfg, date,
            lat_min, lat_max, lon_min, lon_max, max_pixels,
        )
        return Response(
            content=png_bytes,
            media_type="image/png",
            headers={
                "Cache-Control": "public, max-age=3600",
                "X-Date-Matched": matched,
                "X-Variable": variable,
                "X-Dataset-Id": cfg["dataset_id"],
                "X-Bounds-West": str(bounds["west"]),
                "X-Bounds-South": str(bounds["south"]),
                "X-Bounds-East": str(bounds["east"]),
                "X-Bounds-North": str(bounds["north"]),
                "X-Raster-Width": str(bounds["width"]),
                "X-Raster-Height": str(bounds["height"]),
                "Access-Control-Expose-Headers": "X-Date-Matched, X-Variable, X-Dataset-Id, X-Bounds-West, X-Bounds-South, X-Bounds-East, X-Bounds-North, X-Raster-Width, X-Raster-Height",
            },
        )
    except ConnectionError as exc:
        logger.error(f"[ONLINE] OPeNDAP connection error for '{variable}': {exc}")
        raise HTTPException(status_code=502, detail=f"Unable to retrieve online dataset: {exc}")
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:
        logger.error(f"[ONLINE] Frame render error for '{variable}' {date}: {exc}", exc_info=True)
        raise HTTPException(
            status_code=502,
            detail=f"Unable to render frame for '{variable}' on {date}: {exc}",
        )



# ─────────────────────────────────────────────────────────────────────────────
#  Point query (click-to-query)
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/{variable}/point")
async def get_point(
    variable: str,
    date: str = Query(..., description="Date YYYY-MM-DD or 'latest'"),
    lon: float = Query(..., ge=-180, le=180),
    lat: float = Query(..., ge=-90, le=90),
):
    """
    Return the value of a variable at a specific location and date.

    Uses a small spatial window around the point to minimise OPeNDAP download.
    Returns the actual matched date (which may differ from requested date if
    the exact date is not available).
    """
    _require_xarray()
    cfg = _get_config(variable)
    loop = asyncio.get_event_loop()

    # Resolve 'latest'
    if date == "latest":
        try:
            date = await loop.run_in_executor(_executor, get_latest_time, variable, cfg)
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Cannot determine latest time: {exc}")

    try:
        result = await loop.run_in_executor(
            _executor, query_point, variable, cfg, date, lon, lat
        )
        return result
    except ConnectionError as exc:
        raise HTTPException(status_code=502, detail=f"Unable to retrieve online dataset: {exc}")
    except Exception as exc:
        logger.error(f"[ONLINE] Point query error for '{variable}': {exc}", exc_info=True)
        raise HTTPException(
            status_code=502,
            detail=f"Unable to query point for '{variable}': {exc}",
        )
