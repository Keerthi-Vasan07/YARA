"""
YARA Copernicus Marine online dataset registry.

Primary dataset:
    cmems_mod_glo_phy_my_0.083deg_P1D-m

Variables:
    uo       - Eastward sea water velocity
    vo       - Northward sea water velocity
    thetao   - Sea water potential temperature
    so       - Sea water salinity
    zos      - Sea surface height
    mlotst   - Mixed layer thickness
    bottomT  - Bottom temperature
    siconc   - Sea ice concentration
    sithick  - Sea ice thickness
    usi      - Sea ice eastward velocity
    vsi      - Sea ice northward velocity

The actual remote data access is handled through
Copernicus Marine Toolbox + xarray/Dask.
"""

from typing import Any, Dict




# ---------------------------------------------------------------------------
# Canonical Copernicus dataset
# ---------------------------------------------------------------------------

COPERNICUS_DATASET_ID = "cmems_mod_glo_phy_my_0.083deg_P1D-m"


# ---------------------------------------------------------------------------
# Variable registry
# ---------------------------------------------------------------------------

ONLINE_DATASETS: Dict[str, Dict[str, Any]] = {

    "uo": {
        "dataset_id": COPERNICUS_DATASET_ID,
        "variable": "uo",
        "display_name": "Eastward Sea Water Velocity",
        "units": "m s-1",
        "units_display": "m/s",
        "temporal_resolution": "daily",
        "spatial_resolution_deg": 0.083,
        "dimensions": ["time", "depth", "latitude", "longitude"],
        "vmin": -2.0,
        "vmax": 2.0,
        "description": "Eastward sea water velocity from the Copernicus Marine global ocean physics reanalysis.",
        "source": "Copernicus Marine Service",
        "provider": "Copernicus",
    },

    "vo": {
        "dataset_id": COPERNICUS_DATASET_ID,
        "variable": "vo",
        "display_name": "Northward Sea Water Velocity",
        "units": "m s-1",
        "units_display": "m/s",
        "temporal_resolution": "daily",
        "spatial_resolution_deg": 0.083,
        "dimensions": ["time", "depth", "latitude", "longitude"],
        "vmin": -2.0,
        "vmax": 2.0,
        "description": "Northward sea water velocity from the Copernicus Marine global ocean physics reanalysis.",
        "source": "Copernicus Marine Service",
        "provider": "Copernicus",
    },

    "thetao": {
        "dataset_id": COPERNICUS_DATASET_ID,
        "variable": "thetao",
        "display_name": "Sea Water Potential Temperature",
        "units": "degrees_C",
        "units_display": "°C",
        "temporal_resolution": "daily",
        "spatial_resolution_deg": 0.083,
        "dimensions": ["time", "depth", "latitude", "longitude"],
        "vmin": -2.0,
        "vmax": 35.0,
        "description": "Three-dimensional sea water potential temperature.",
        "source": "Copernicus Marine Service",
        "provider": "Copernicus",
    },

    "so": {
        "dataset_id": COPERNICUS_DATASET_ID,
        "variable": "so",
        "display_name": "Sea Water Salinity",
        "units": "psu",
        "units_display": "PSU",
        "temporal_resolution": "daily",
        "spatial_resolution_deg": 0.083,
        "dimensions": ["time", "depth", "latitude", "longitude"],
        "vmin": 30.0,
        "vmax": 40.0,
        "description": "Three-dimensional sea water salinity.",
        "source": "Copernicus Marine Service",
        "provider": "Copernicus",
    },

    "zos": {
        "dataset_id": COPERNICUS_DATASET_ID,
        "variable": "zos",
        "display_name": "Sea Surface Height",
        "units": "m",
        "units_display": "m",
        "temporal_resolution": "daily",
        "spatial_resolution_deg": 0.083,
        "dimensions": ["time", "latitude", "longitude"],
        "vmin": -2.0,
        "vmax": 2.0,
        "description": "Sea surface height above geoid.",
        "source": "Copernicus Marine Service",
        "provider": "Copernicus",
    },

    "mlotst": {
        "dataset_id": COPERNICUS_DATASET_ID,
        "variable": "mlotst",
        "display_name": "Mixed Layer Thickness",
        "units": "m",
        "units_display": "m",
        "temporal_resolution": "daily",
        "spatial_resolution_deg": 0.083,
        "dimensions": ["time", "latitude", "longitude"],
        "vmin": 0.0,
        "vmax": 500.0,
        "description": "Ocean mixed layer thickness.",
        "source": "Copernicus Marine Service",
        "provider": "Copernicus",
    },

    "bottomT": {
        "dataset_id": COPERNICUS_DATASET_ID,
        "variable": "bottomT",
        "display_name": "Bottom Temperature",
        "units": "degrees_C",
        "units_display": "°C",
        "temporal_resolution": "daily",
        "spatial_resolution_deg": 0.083,
        "dimensions": ["time", "latitude", "longitude"],
        "vmin": -2.0,
        "vmax": 35.0,
        "description": "Sea water temperature at the ocean bottom.",
        "source": "Copernicus Marine Service",
        "provider": "Copernicus",
    },

    "siconc": {
        "dataset_id": COPERNICUS_DATASET_ID,
        "variable": "siconc",
        "display_name": "Sea Ice Concentration",
        "units": "1",
        "units_display": "%",
        "temporal_resolution": "daily",
        "spatial_resolution_deg": 0.083,
        "dimensions": ["time", "latitude", "longitude"],
        "vmin": 0.0,
        "vmax": 1.0,
        "description": "Sea ice concentration.",
        "source": "Copernicus Marine Service",
        "provider": "Copernicus",
    },

    "sithick": {
        "dataset_id": COPERNICUS_DATASET_ID,
        "variable": "sithick",
        "display_name": "Sea Ice Thickness",
        "units": "m",
        "units_display": "m",
        "temporal_resolution": "daily",
        "spatial_resolution_deg": 0.083,
        "dimensions": ["time", "latitude", "longitude"],
        "vmin": 0.0,
        "vmax": 5.0,
        "description": "Sea ice thickness.",
        "source": "Copernicus Marine Service",
        "provider": "Copernicus",
    },

    "usi": {
        "dataset_id": COPERNICUS_DATASET_ID,
        "variable": "usi",
        "display_name": "Eastward Sea Ice Velocity",
        "units": "m s-1",
        "units_display": "m/s",
        "temporal_resolution": "daily",
        "spatial_resolution_deg": 0.083,
        "dimensions": ["time", "latitude", "longitude"],
        "vmin": -1.0,
        "vmax": 1.0,
        "description": "Eastward sea ice velocity.",
        "source": "Copernicus Marine Service",
        "provider": "Copernicus",
    },

    "vsi": {
        "dataset_id": COPERNICUS_DATASET_ID,
        "variable": "vsi",
        "display_name": "Northward Sea Ice Velocity",
        "units": "m s-1",
        "units_display": "m/s",
        "temporal_resolution": "daily",
        "spatial_resolution_deg": 0.083,
        "dimensions": ["time", "latitude", "longitude"],
        "vmin": -1.0,
        "vmax": 1.0,
        "description": "Northward sea ice velocity.",
        "source": "Copernicus Marine Service",
        "provider": "Copernicus",
    },
}


DATASET_BY_ID: Dict[str, str] = {
    COPERNICUS_DATASET_ID: "copernicus_global_physics"
}


def get_dataset_config(variable_key: str) -> Dict[str, Any]:
    cfg = ONLINE_DATASETS.get(variable_key)

    if cfg is None:
        raise KeyError(
            f"Unknown online variable '{variable_key}'. "
            f"Registered variables: {list(ONLINE_DATASETS.keys())}"
        )

    return cfg