"""
Copernicus Marine remote data access for YARA.

Uses:
    copernicusmarine.open_dataset()
    xarray
    dask

Data is requested remotely and subsetted before values are loaded.
"""

from __future__ import annotations

import io
import logging
from functools import lru_cache
from typing import Any, Dict, Tuple

import numpy as np
import matplotlib

logger = logging.getLogger(__name__)


try:
    import xarray as xr
    HAS_XARRAY = True
except ImportError:
    xr = None
    HAS_XARRAY = False


try:
    import copernicusmarine
    HAS_COPERNICUS = True
except ImportError:
    copernicusmarine = None
    HAS_COPERNICUS = False


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _require_dependencies():
    if not HAS_XARRAY:
        raise RuntimeError("xarray is not installed")

    if not HAS_COPERNICUS:
        raise RuntimeError(
            "copernicusmarine is not installed"
        )


def _dataset_id(cfg: Dict[str, Any]) -> str:
    return cfg["dataset_id"]


@lru_cache(maxsize=16)
def _open_dataset_cached(
    dataset_id: str,
    variable: str,
):
    """
    Open the Copernicus dataset lazily.

    IMPORTANT:
    This does NOT download the full dataset.
    xarray/Dask keeps the remote arrays lazy.
    """

    _require_dependencies()

    logger.info(
        "[COPERNICUS] Opening dataset=%s variable=%s",
        dataset_id,
        variable,
    )

    ds = copernicusmarine.open_dataset(
        dataset_id=dataset_id,
        variables=[variable],
    )

    return ds


def open_remote_dataset(
    variable: str,
    cfg: Dict[str, Any],
    *,
    minimum_longitude: float | None = None,
    maximum_longitude: float | None = None,
    minimum_latitude: float | None = None,
    maximum_latitude: float | None = None,
    minimum_depth: float | None = None,
    maximum_depth: float | None = None,
    start_datetime: str | None = None,
    end_datetime: str | None = None,
):
    """
    Open only the requested Copernicus subset.
    """

    _require_dependencies()

    kwargs: Dict[str, Any] = {
        "dataset_id": _dataset_id(cfg),
        "variables": [variable],
    }

    if minimum_longitude is not None:
        kwargs["minimum_longitude"] = minimum_longitude

    if maximum_longitude is not None:
        kwargs["maximum_longitude"] = maximum_longitude

    if minimum_latitude is not None:
        kwargs["minimum_latitude"] = minimum_latitude

    if maximum_latitude is not None:
        kwargs["maximum_latitude"] = maximum_latitude

    if minimum_depth is not None:
        kwargs["minimum_depth"] = minimum_depth

    if maximum_depth is not None:
        kwargs["maximum_depth"] = maximum_depth

    if start_datetime is not None:
        kwargs["start_datetime"] = start_datetime

    if end_datetime is not None:
        kwargs["end_datetime"] = end_datetime

    logger.info(
        "[COPERNICUS] subset request: %s",
        kwargs,
    )

    return copernicusmarine.open_dataset(**kwargs)


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------

def inspect_dataset_metadata(
    variable: str,
    cfg: Dict[str, Any],
) -> Dict[str, Any]:

    ds = _open_dataset_cached(
        _dataset_id(cfg),
        variable,
    )

    try:
        data = ds[variable]

        dimensions = {}

        for dim in data.dims:
            coord = ds.coords.get(dim)

            info: Dict[str, Any] = {
                "size": int(ds.sizes[dim]),
            }

            if coord is not None:
                try:
                    values = coord.values

                    if values.size:
                        info["min"] = str(values.min())
                        info["max"] = str(values.max())
                except Exception:
                    pass

            dimensions[dim] = info

        return {
            "variable": variable,
            "display_name": cfg["display_name"],
            "dataset_id": cfg["dataset_id"],
            "units": cfg["units"],
            "units_display": cfg["units_display"],
            "dimensions": dimensions,
            "shape": list(data.shape),
            "dtype": str(data.dtype),
            "description": cfg["description"],
            "source": cfg["source"],
            "provider": cfg["provider"],
        }

    finally:
        # Dataset remains cached/lazy.
        pass


# ---------------------------------------------------------------------------
# Time
# ---------------------------------------------------------------------------

def get_latest_time(
    variable: str,
    cfg: Dict[str, Any],
) -> str:

    ds = _open_dataset_cached(
        _dataset_id(cfg),
        variable,
    )

    if "time" not in ds.coords:
        raise ValueError(
            f"Dataset for '{variable}' does not contain a time coordinate"
        )

    latest = ds["time"].values[-1]

    return str(np.datetime_as_string(latest, unit="D"))


def get_available_times(
    variable: str,
    cfg: Dict[str, Any],
):

    ds = _open_dataset_cached(
        _dataset_id(cfg),
        variable,
    )

    if "time" not in ds.coords:
        return []

    values = ds["time"].values

    return [
        str(np.datetime_as_string(value, unit="D"))
        for value in values
    ]


# ---------------------------------------------------------------------------
# Date matching
# ---------------------------------------------------------------------------

def _select_date(ds, date: str):
    """
    Select exact date where possible.
    Otherwise select nearest available timestamp.
    """

    if "time" not in ds.coords:
        return ds, None

    requested = np.datetime64(date)

    try:
        selected = ds.sel(
            time=requested,
            method="nearest",
        )

        matched = selected["time"].values

        if np.ndim(matched):
            matched = matched.item()

        matched = str(
            np.datetime_as_string(
                np.datetime64(matched),
                unit="D",
            )
        )

        return selected, matched

    except Exception as exc:
        raise ValueError(
            f"Unable to match date '{date}': {exc}"
        ) from exc


# ---------------------------------------------------------------------------
# PNG rendering
# ---------------------------------------------------------------------------

def render_to_png(
    variable: str,
    cfg: Dict[str, Any],
    date: str,
    lat_min: float,
    lat_max: float,
    lon_min: float,
    lon_max: float,
    max_pixels: int,
) -> Tuple[bytes, str, Dict[str, Any]]:

    ds = open_remote_dataset(
        variable,
        cfg,
        minimum_longitude=lon_min,
        maximum_longitude=lon_max,
        minimum_latitude=lat_min,
        maximum_latitude=lat_max,
        start_datetime=date,
        end_datetime=date,
    )

    ds, matched = _select_date(ds, date)

    data = ds[variable]

    # If the variable has depth, default to surface.
    if "depth" in data.dims:
        data = data.isel(depth=0)

    # Remove singleton dimensions.
    data = data.squeeze(drop=True)

    if "latitude" not in data.dims or "longitude" not in data.dims:
        raise ValueError(
            f"Variable '{variable}' cannot be rendered as a geographic frame"
        )

    # Extract coordinate arrays before any slicing
    lat_values = data["latitude"].values
    lon_values = data["longitude"].values

    if lat_values.size == 0 or lon_values.size == 0:
        raise ValueError(f"No spatial coordinates found for '{variable}' on {date}")

    # Derive dlat and dlon dynamically from actual coordinate arrays
    if len(lat_values) > 1:
        dlat = abs(float(lat_values[1] - lat_values[0]))
    else:
        dlat = float(cfg.get("spatial_resolution_deg", 0.08333333333333333))

    if len(lon_values) > 1:
        dlon = abs(float(lon_values[1] - lon_values[0]))
    else:
        dlon = float(cfg.get("spatial_resolution_deg", 0.08333333333333333))

    # Calculate exact outer cell-edge bounds
    edge_lat_min = float(np.min(lat_values)) - dlat / 2.0
    edge_lat_max = float(np.max(lat_values)) + dlat / 2.0
    edge_lon_min = float(np.min(lon_values)) - dlon / 2.0
    edge_lon_max = float(np.max(lon_values)) + dlon / 2.0

    # Downsample only if necessary.
    lat_size = data.sizes["latitude"]
    lon_size = data.sizes["longitude"]

    if lat_size * lon_size > max_pixels * max_pixels:

        lat_stride = max(
            1,
            int(np.ceil(lat_size / max_pixels)),
        )

        lon_stride = max(
            1,
            int(np.ceil(lon_size / max_pixels)),
        )

        data = data.isel(
            latitude=slice(None, None, lat_stride),
            longitude=slice(None, None, lon_stride),
        )

    # Load ONLY this requested subset.
    arr = data.load().values.astype(np.float32)

    arr = np.squeeze(arr)

    # Replace invalid values.
    finite = np.isfinite(arr)

    if not finite.any():
        raise ValueError(
            f"No valid data available for '{variable}' on {date}"
        )

    # Value ranges — use registry defaults
    vmin_val = float(cfg["vmin"])
    vmax_val = float(cfg["vmax"])

    if vmin_val >= vmax_val:
        vmax_val = vmin_val + 1e-5

    # Normalize values (linear)
    normalized = (arr - vmin_val) / (vmax_val - vmin_val)
    normalized = np.clip(normalized, 0.0, 1.0)

    # Fixed viridis colormap
    import matplotlib.cm as cm
    cmap = matplotlib.colormaps["viridis"]

    # Map normalized array through colormap (returns floats 0.0 .. 1.0)
    colored = cmap(normalized)
    rgba = (colored * 255).astype(np.uint8)

    # Set alpha to 0 for non-finite values (NaN / fill values)
    rgba[..., 3] = np.where(
        finite,
        255,
        0,
    ).astype(np.uint8)

    # Flip latitude if latitude increases from South to North so row 0 is North (top of image)
    try:
        if len(lat_values) > 1 and lat_values[0] < lat_values[-1]:
            rgba = np.flipud(rgba)
    except Exception:
        pass

    try:
        from PIL import Image
    except ImportError as exc:
        raise RuntimeError(
            "Pillow is required for PNG rendering"
        ) from exc

    image = Image.fromarray(rgba, mode="RGBA")

    buffer = io.BytesIO()

    image.save(
        buffer,
        format="PNG",
        optimize=True,
    )

    bounds_dict = {
        "west": edge_lon_min,
        "south": edge_lat_min,
        "east": edge_lon_max,
        "north": edge_lat_max,
        "width": int(rgba.shape[1]),
        "height": int(rgba.shape[0]),
    }

    return buffer.getvalue(), matched or date, bounds_dict



# ---------------------------------------------------------------------------
# Point query
# ---------------------------------------------------------------------------

def query_point(
    variable: str,
    cfg: Dict[str, Any],
    date: str,
    lon: float,
    lat: float,
):

    ds = open_remote_dataset(
        variable,
        cfg,
        minimum_longitude=lon - 0.1,
        maximum_longitude=lon + 0.1,
        minimum_latitude=lat - 0.1,
        maximum_latitude=lat + 0.1,
        start_datetime=date,
        end_datetime=date,
    )

    ds, matched = _select_date(ds, date)

    data = ds[variable]

    if "longitude" in data.dims:
        data = data.sel(
            longitude=lon,
            method="nearest",
        )

    if "latitude" in data.dims:
        data = data.sel(
            latitude=lat,
            method="nearest",
        )

    result = {
        "variable": variable,
        "display_name": cfg["display_name"],
        "dataset_id": cfg["dataset_id"],
        "requested_date": date,
        "matched_date": matched or date,
        "longitude": lon,
        "latitude": lat,
        "units": cfg["units_display"],
    }

    # Depth-dependent variables return all depth values.
    if "depth" in data.dims:

        values = data.load().values

        depth_values = ds["depth"].values

        result["depth_values"] = [
            float(v) for v in depth_values
        ]

        result["values"] = [
            None if not np.isfinite(v) else float(v)
            for v in values
        ]

    else:

        value = data.load().values

        value = np.asarray(value).squeeze()

        if value.size == 0:
            result["value"] = None
        else:
            value = float(value)

            result["value"] = (
                None
                if not np.isfinite(value)
                else value
            )

    return result