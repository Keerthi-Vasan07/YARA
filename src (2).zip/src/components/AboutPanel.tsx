/**
 * About Panel - Product info and OceanStream branding
 */


import {
  Box,
  Paper,
  Typography,
  IconButton,
  Link,
  Divider,
} from '@mui/material';
import { useEffect } from 'react';
import {
  Close as CloseIcon,
  GitHub as GitHubIcon,
  Language as LanguageIcon,
  Email as EmailIcon,
} from '@mui/icons-material';

// Color scheme - warm amber/orange accent on very dark background
const ACCENT_COLOR = '#FFB347';
const BORDER_COLOR = 'rgba(255, 180, 50, 0.12)';
const BG_DARK = '#0a0a0a';
const TEXT_PRIMARY = 'rgba(255, 255, 255, 0.92)';
const TEXT_SECONDARY = 'rgba(255, 255, 255, 0.55)';

// OceanStream Logo SVG component
function OceanStreamLogo() {
  return (
    <svg width="220" height="34" viewBox="0 0 304 49" fill="none" xmlns="http://www.w3.org/2000/svg">
      <g clipPath="url(#clip0_about)">
        <path d="M-2.15437e-05 20.7316C-0.0117656 17.9387 0.805205 15.205 2.3481 12.8773C3.89099 10.5496 6.09011 8.73255 8.6664 7.65648C11.2427 6.58042 14.0803 6.29344 16.8196 6.83255C19.5589 7.37167 22.0764 8.71248 24.0532 10.6846C26.0301 12.6568 27.3774 15.1717 27.924 17.9107C28.4706 20.6496 28.1919 23.4894 27.1236 26.0698C26.0552 28.6502 24.2452 30.8551 21.9228 32.4052C19.6005 33.9553 16.8704 34.7804 14.0786 34.7766C12.2242 34.8086 10.3825 34.4675 8.66253 33.7734C6.94256 33.0794 5.37947 32.0467 4.06622 30.7366C2.75298 29.4265 1.71618 27.8658 1.01763 26.147C0.319076 24.4283 -0.0267918 22.5868 -2.15437e-05 20.7316ZM20.1888 20.7316C20.1538 19.5309 19.7659 18.3667 19.0736 17.3852C18.3813 16.4037 17.4154 15.6478 16.2963 15.2124C15.1772 14.7769 13.9547 14.681 12.7814 14.9366C11.6081 15.1922 10.5358 15.7881 9.69901 16.6497C8.86221 17.5112 8.29768 18.6001 8.07599 19.7807C7.85429 20.9613 7.98531 22.1813 8.45254 23.2879C8.91976 24.3945 9.70256 25.339 10.7031 26.0031C11.7037 26.6672 12.8778 27.0217 14.0786 27.0222C14.9033 27.0484 15.7244 26.902 16.4894 26.5928C17.2545 26.2836 17.9468 25.8181 18.5218 25.226C19.0969 24.634 19.5421 23.9286 19.8291 23.1546C20.1161 22.3807 20.2387 21.5556 20.1888 20.7316Z" fill="#EDFEFF"/>
        <path d="M29.5818 20.732C29.5984 17.6633 30.6163 14.6837 32.4807 12.2469C34.3452 9.81008 36.9541 8.04914 39.9108 7.23185C42.8675 6.41456 46.0101 6.58567 48.8606 7.71916C51.7111 8.85264 54.1136 10.8864 55.7027 13.5113L48.7225 17.4677C48.2431 16.5295 47.5024 15.7504 46.5902 15.2239C45.678 14.6973 44.633 14.446 43.5812 14.5004C42.0079 14.5896 40.5287 15.2777 39.4464 16.4235C38.3641 17.5693 37.7611 19.086 37.7611 20.6625C37.7611 22.2389 38.3641 23.7556 39.4464 24.9014C40.5287 26.0472 42.0079 26.7353 43.5812 26.8245C44.6338 26.884 45.6809 26.6349 46.5941 26.1078C47.5073 25.5807 48.2471 24.7986 48.7225 23.8572L55.7027 27.8136C54.4952 29.9272 52.7424 31.6773 50.6275 32.8813C48.5126 34.0854 46.1132 34.699 43.6802 34.6581C41.8343 34.6924 40.0002 34.3574 38.2859 33.6719C36.5715 32.9864 35.0115 31.9646 33.6978 30.6669C32.384 29.3692 31.343 27.8218 30.6361 26.1155C29.9292 24.4093 29.5709 22.579 29.5818 20.732Z" fill="#EDFEFF"/>
        <path d="M70.0977 27.6554C71.0375 27.6876 71.974 27.5284 72.8508 27.1884C73.7276 26.8484 74.5263 26.3347 75.1989 25.6772L81.5863 29.3366C80.2577 31.1415 78.5011 32.5876 76.4749 33.5442C74.4486 34.5007 72.2161 34.9378 69.9789 34.8163C60.883 34.8163 55.2476 28.7035 55.2476 20.7709C55.1949 18.9029 55.5258 17.0443 56.2204 15.3096C56.915 13.5749 57.9586 12.0011 59.2859 10.6862C60.6132 9.37132 62.196 8.34315 63.9367 7.6653C65.6775 6.98745 67.5388 6.67458 69.4054 6.74575C71.2271 6.7304 73.0329 7.08674 74.7123 7.7928C76.3918 8.49886 77.9096 9.5398 79.1735 10.8523C80.4373 12.1649 81.4207 13.7211 82.0632 15.4264C82.7058 17.1318 82.9943 18.9503 82.9109 20.7709C82.9131 21.848 82.8005 22.9225 82.575 23.9758H63.7108C64.7193 26.7057 67.1712 27.6554 70.0977 27.6554ZM74.9817 17.9818C74.634 16.7329 73.8871 15.6325 72.8552 14.8483C71.8232 14.0642 70.5627 13.6395 69.2668 13.6395C67.971 13.6395 66.711 14.0642 65.679 14.8483C64.6471 15.6325 63.9002 16.7329 63.5525 17.9818H74.9817Z" fill="#EDFEFF"/>
        <path d="M112.651 7.43822V34.0454H104.741V31.533C103.744 32.6247 102.518 33.4815 101.15 34.0425C99.7824 34.6034 98.3078 34.8543 96.8317 34.7771C89.8714 34.7771 84.1367 28.6647 84.1367 20.7321C84.1367 12.7996 89.8714 6.70654 96.8317 6.70654C98.3059 6.62955 99.779 6.87849 101.146 7.43581C102.513 7.99313 103.741 8.84489 104.741 9.93077V7.43822H112.651ZM104.741 20.7321C104.706 19.4883 104.306 18.2823 103.589 17.265C102.873 16.2477 101.873 15.4639 100.714 15.012C99.5552 14.56 98.2891 14.4597 97.0736 14.7237C95.8581 14.9876 94.7474 15.6041 93.8802 16.4961C93.0129 17.3881 92.4278 18.5163 92.1978 19.7392C91.9677 20.962 92.1027 22.2256 92.5864 23.372C93.0701 24.5184 93.8808 25.4962 94.9171 26.1843C95.9535 26.8723 97.1699 27.2395 98.4137 27.24C99.2653 27.27 100.113 27.1207 100.903 26.801C101.693 26.4813 102.407 25.9984 102.998 25.3845C103.59 24.7706 104.045 24.0394 104.335 23.2377C104.625 22.4361 104.743 21.5824 104.682 20.7321H104.741Z" fill="#EDFEFF"/>
        <path d="M142.252 17.7051V34.045H134.342V18.8719C134.41 18.2402 134.338 17.6018 134.134 17.0005C133.929 16.3991 133.596 15.8492 133.157 15.3898C132.719 14.9304 132.186 14.5721 131.595 14.3398C131.004 14.1076 130.369 14.0072 129.735 14.0452C126.808 14.0452 124.772 15.7465 124.772 19.5051V34.045H116.862V7.43787H124.772V9.93042C125.699 8.83328 126.871 7.97001 128.194 7.40986C129.516 6.84972 130.952 6.60865 132.385 6.70619C137.724 6.64685 142.252 10.6034 142.252 17.7051Z" fill="#EDFEFF"/>
        <path d="M166.573 26.0529C166.573 32.1853 161.254 34.7765 155.52 34.7765C150.2 34.7765 146.167 32.7984 144.09 28.4464L151.011 24.49C151.29 25.4496 151.89 26.284 152.711 26.8531C153.532 27.4223 154.524 27.6917 155.52 27.6157C157.497 27.6157 158.406 27.0419 158.406 25.9737C158.406 23.0459 145.317 24.5887 145.317 15.3901C145.317 9.59397 150.201 6.66641 155.737 6.66641C157.817 6.59807 159.876 7.09109 161.699 8.09355C163.522 9.09601 165.042 10.5707 166.099 12.3634L159.296 16.0233C158.987 15.3352 158.488 14.7499 157.858 14.3363C157.227 13.9227 156.491 13.6983 155.737 13.6891C154.353 13.6891 153.503 14.2034 153.503 15.1728C153.542 18.239 166.573 16.2212 166.573 26.0529Z" fill="#6EF2FC"/>
        <path d="M178.121 15.0935V24.4504C178.121 26.7253 180.098 26.9427 183.578 26.7251V33.9656C173.157 35.0141 170.132 31.9873 170.132 24.4504V15.0143H165.881V7.35895H170.132V2.31444L178.041 -0.0791016V7.35895H183.499V15.0143L178.121 15.0935Z" fill="#6EF2FC"/>
        <path d="M202.818 6.90368V15.9442C199.516 15.4299 194.908 16.7554 194.908 22.0174V34.045H186.999V7.43784H194.908V12.1858C195.476 10.5665 196.555 9.17534 197.981 8.22265C199.408 7.26995 201.105 6.80701 202.818 6.90368Z" fill="#6EF2FC"/>
        <path d="M217.49 27.6557C218.43 27.6879 219.367 27.5287 220.244 27.1887C221.12 26.8487 221.919 26.3349 222.592 25.6775L228.979 29.3369C227.65 31.1418 225.894 32.5879 223.868 33.5445C221.841 34.501 219.609 34.9381 217.372 34.8166C208.276 34.8166 202.64 28.7037 202.64 20.7712C202.574 18.8933 202.895 17.022 203.585 15.2741C204.274 13.5263 205.317 11.94 206.648 10.6141C207.979 9.28814 209.569 8.25111 211.319 7.56852C213.069 6.88592 214.941 6.57231 216.818 6.64703C218.64 6.63168 220.445 6.98802 222.125 7.69408C223.804 8.40015 225.322 9.44109 226.586 10.7536C227.85 12.0662 228.833 13.6229 229.476 15.3282C230.118 17.0336 230.407 18.8521 230.324 20.6726C230.322 21.7486 230.216 22.8216 230.007 23.8771H211.123C212.112 26.7059 214.564 27.6557 217.49 27.6557ZM222.375 17.9821C222.027 16.7332 221.28 15.6328 220.248 14.8486C219.216 14.0645 217.956 13.6398 216.66 13.6398C215.364 13.6398 214.104 14.0645 213.072 14.8486C212.04 15.6328 211.293 16.7332 210.945 17.9821H222.375Z" fill="#6EF2FC"/>
        <path d="M260.043 7.43781V34.045H252.134V31.5326C251.136 32.6232 249.909 33.4793 248.542 34.0402C247.174 34.601 245.7 34.8526 244.224 34.7767C237.264 34.7767 231.529 28.6643 231.529 20.7317C231.529 12.7992 237.264 6.70613 244.224 6.70613C245.698 6.63188 247.17 6.88211 248.537 7.43926C249.903 7.99641 251.132 8.84666 252.134 9.93036V7.43781H260.043ZM252.134 20.7317C252.099 19.4879 251.698 18.2819 250.982 17.2646C250.266 16.2473 249.265 15.4635 248.107 15.0116C246.948 14.5596 245.682 14.4593 244.466 14.7232C243.251 14.9872 242.14 15.6037 241.273 16.4957C240.406 17.3877 239.82 18.5159 239.59 19.7388C239.36 20.9616 239.495 22.2252 239.979 23.3716C240.463 24.518 241.273 25.4958 242.31 26.1839C243.346 26.8719 244.562 27.2391 245.806 27.2396C246.657 27.2665 247.504 27.1151 248.292 26.7943C249.081 26.4736 249.794 25.9906 250.384 25.3773C250.975 24.7641 251.43 24.0342 251.721 23.2339C252.013 22.4337 252.133 21.5813 252.074 20.7317H252.134Z" fill="#6EF2FC"/>
        <path d="M304 17.7053V34.0452H296.091V18.3974C296.091 15.7466 294.805 14.0454 292.254 14.0454C289.703 14.0454 288.102 15.905 288.102 19.0305V34.0452H280.193V18.3974C280.193 15.7466 278.927 14.0454 276.376 14.0454C273.826 14.0454 272.204 15.905 272.204 19.0305V34.0452H264.294V7.43806H272.204V9.89101C273.035 8.80817 274.123 7.95023 275.37 7.39411C276.616 6.838 277.982 6.60154 279.342 6.70638C280.706 6.63943 282.063 6.92687 283.283 7.54045C284.503 8.15402 285.543 9.07288 286.302 10.2078C287.188 9.02098 288.36 8.07729 289.709 7.46511C291.057 6.85292 292.538 6.59208 294.014 6.70638C300.006 6.64703 304 11.0585 304 17.7053Z" fill="#6EF2FC"/>
        <path d="M14.0193 21.2656L2.80762 46.1712H25.2112L14.0193 21.2656Z" fill="#3E7E9A"/>
        <path d="M17.4401 33.9855C15.1826 34.7883 12.7175 34.7883 10.46 33.9855L13.426 26.9232C13.4681 26.8159 13.5417 26.7236 13.637 26.6586C13.7322 26.5936 13.8446 26.5591 13.9599 26.5591C14.0752 26.5591 14.1881 26.5936 14.2834 26.6586C14.3786 26.7236 14.4518 26.8159 14.4939 26.9232L17.4401 33.9855Z" fill="#EDFEFF"/>
        <path d="M19.9515 39.9993C18.1811 41.2064 16.0937 41.8635 13.9513 41.8881C11.809 41.9127 9.70734 41.3035 7.90967 40.1374L9.62972 36.0231C10.9908 36.4967 12.4205 36.7437 13.8616 36.7547C15.3619 36.7536 16.8495 36.479 18.2512 35.9438L19.9515 39.9993Z" fill="#EDFEFF"/>
        <path d="M22.2056 46.9031C19.6739 48.2761 16.8394 48.9948 13.9596 48.9948C11.0799 48.9948 8.24587 48.2761 5.71419 46.9031C5.57144 46.82 5.463 46.6886 5.40861 46.5326C5.35422 46.3767 5.35765 46.206 5.41778 46.0521L7.05867 42.0957C9.11615 43.3342 11.4607 44.0159 13.8612 44.0739C16.308 44.0776 18.7064 43.3921 20.7819 42.0957L22.502 46.1709C22.533 46.3086 22.5212 46.4525 22.4682 46.5834C22.4152 46.7142 22.3237 46.8259 22.2056 46.9031Z" fill="#EDFEFF"/>
      </g>
      <defs>
        <clipPath id="clip0_about">
          <rect width="304" height="49" fill="white"/>
        </clipPath>
      </defs>
    </svg>
  );
}

interface AboutPanelProps {
  open: boolean;
  onClose: () => void;
}

export function AboutPanel({ open, onClose }: AboutPanelProps) {
  // Close on Escape key
  useEffect(() => {
    if (!open) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <Box
      sx={{
        position: 'fixed',
        inset: 0,
        zIndex: 1200,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      {/* Backdrop */}
      <Box
        onClick={onClose}
        sx={{
          position: 'absolute',
          inset: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
        }}
      />

      {/* Main Panel */}
      <Paper
        elevation={0}
        sx={{
          position: 'relative',
          width: '90vw',
          maxWidth: 680,
          maxHeight: '90vh',
          backgroundColor: BG_DARK,
          borderRadius: 0,
          border: `1px solid ${BORDER_COLOR}`,
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
        }}
      >
        {/* Header */}
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            px: 3,
            py: 2,
            borderBottom: `1px solid ${BORDER_COLOR}`,
          }}
        >
          <Typography
            variant="h6"
            sx={{
              color: TEXT_PRIMARY,
              fontWeight: 500,
              letterSpacing: '0.02em',
            }}
          >
            About
          </Typography>
          <IconButton onClick={onClose} size="small" sx={{ color: TEXT_SECONDARY }}>
            <CloseIcon />
          </IconButton>
        </Box>

        {/* Content */}
        <Box sx={{ p: 4, overflow: 'auto', flexGrow: 1 }}>
          {/* Logo/Brand */}
          <Box sx={{ textAlign: 'center', mb: 3 }}>
            <OceanStreamLogo />
            <Typography
              variant="body2"
              sx={{
                color: ACCENT_COLOR,
                fontFamily: 'monospace',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                fontSize: '0.7rem',
                mt: 1.5,
              }}
            >
              Physics & Biogeochem
            </Typography>
          </Box>

          {/* Preview Badge */}
          <Box sx={{ textAlign: 'center', mb: 3 }}>
            <Box
              sx={{
                display: 'inline-block',
                px: 2,
                py: 0.5,
                border: `1px solid ${ACCENT_COLOR}`,
                borderRadius: 1,
              }}
            >
              <Typography
                variant="caption"
                sx={{
                  color: ACCENT_COLOR,
                  fontWeight: 600,
                  letterSpacing: '0.1em',
                  textTransform: 'uppercase',
                }}
              >
                Preview
              </Typography>
            </Box>
          </Box>

          <Divider sx={{ borderColor: BORDER_COLOR, my: 3 }} />

          {/* Description */}
          <Box sx={{ mb: 4 }}>
            <Typography
              variant="body1"
              sx={{
                color: TEXT_SECONDARY,
                lineHeight: 1.8,
                textAlign: 'center',
              }}
            >
              Interactive 3D visualization of global ocean Essential Climate Variables (ECVs). 
              Explore physical and biogeochemical data on a responsive globe with 
              cloud-optimized streaming.
            </Typography>
          </Box>

          {/* Variables */}
          <Box sx={{ mb: 4 }}>
            <Typography
              variant="subtitle2"
              sx={{ color: TEXT_PRIMARY, mb: 2, textAlign: 'center' }}
            >
              Available Variables
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75 }}>
              {[
                { name: 'Sea Surface Temperature (SST)', source: 'ERA5' },
                { name: 'Sea Ice Concentration (SIC)', source: 'CMEMS' },
                { name: 'Sea Level Anomaly (SLA)', source: 'CMEMS' },
                { name: 'Chlorophyll-a (CHL)', source: 'CMEMS' },
                { name: 'Diffuse Attenuation (Kd490)', source: 'CMEMS' },
                { name: 'Ocean Color (Rrs RGB)', source: 'CMEMS' },
              ].map((variable, i) => (
                <Box
                  key={i}
                  sx={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                  }}
                >
                  <Typography
                    variant="body2"
                    sx={{
                      color: TEXT_SECONDARY,
                      pl: 2,
                      position: 'relative',
                      '&::before': {
                        content: '"•"',
                        position: 'absolute',
                        left: 0,
                        color: ACCENT_COLOR,
                      },
                    }}
                  >
                    {variable.name}
                  </Typography>
                  <Typography
                    variant="caption"
                    sx={{
                      color: 'rgba(255,255,255,0.35)',
                      fontSize: '0.65rem',
                    }}
                  >
                    {variable.source}
                  </Typography>
                </Box>
              ))}
            </Box>
          </Box>

          {/* Features */}
          <Box sx={{ mb: 4 }}>
            <Typography
              variant="subtitle2"
              sx={{ color: TEXT_PRIMARY, mb: 2, textAlign: 'center' }}
            >
              Features
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              {[
                'Global 3D visualization with CesiumJS',
                'Multi-layer overlay support',
                'Point queries and time series analysis',
                'Cloud-optimized GeoTIFF (COG) streaming',
                'Data subset download (NetCDF/GeoTIFF)',
              ].map((feature, i) => (
                <Typography
                  key={i}
                  variant="body2"
                  sx={{
                    color: TEXT_SECONDARY,
                    pl: 2,
                    position: 'relative',
                    '&::before': {
                      content: '"•"',
                      position: 'absolute',
                      left: 0,
                      color: ACCENT_COLOR,
                    },
                  }}
                >
                  {feature}
                </Typography>
              ))}
            </Box>
          </Box>

          <Divider sx={{ borderColor: BORDER_COLOR, my: 3 }} />

          {/* Links */}
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              gap: 3,
              mt: 4,
            }}
          >
            <Link
              href="https://oceanstream.io"
              target="_blank"
              rel="noopener noreferrer"
              sx={{
                display: 'flex',
                alignItems: 'center',
                gap: 0.5,
                color: TEXT_SECONDARY,
                fontSize: '0.875rem',
                textDecoration: 'none',
                '&:hover': { color: ACCENT_COLOR },
              }}
            >
              <LanguageIcon sx={{ fontSize: 16 }} />
              Website
            </Link>
            <Link
              href="https://github.com/OceanStreamIO/arco-3d-globe"
              target="_blank"
              rel="noopener noreferrer"
              sx={{
                display: 'flex',
                alignItems: 'center',
                gap: 0.5,
                color: TEXT_SECONDARY,
                fontSize: '0.875rem',
                textDecoration: 'none',
                '&:hover': { color: ACCENT_COLOR },
              }}
            >
              <GitHubIcon sx={{ fontSize: 16 }} />
              GitHub
            </Link>
            <Link
              href="https://oceanstream.io/contact/"
              target="_blank"
              rel="noopener noreferrer"
              sx={{
                display: 'flex',
                alignItems: 'center',
                gap: 0.5,
                color: TEXT_SECONDARY,
                fontSize: '0.875rem',
                textDecoration: 'none',
                '&:hover': { color: ACCENT_COLOR },
              }}
            >
              <EmailIcon sx={{ fontSize: 16 }} />
              Contact
            </Link>
          </Box>

          {/* Links */}
          <Box sx={{ textAlign: 'center', mt: 3, display: 'flex', justifyContent: 'center', gap: 3 }}>
            <Link
              href="/data"
              sx={{
                color: TEXT_SECONDARY,
                fontSize: '0.75rem',
                textDecoration: 'none',
                '&:hover': { color: ACCENT_COLOR },
              }}
            >
              Data Provenance
            </Link>
            <Link
              href="/terms"
              sx={{
                color: TEXT_SECONDARY,
                fontSize: '0.75rem',
                textDecoration: 'none',
                '&:hover': { color: ACCENT_COLOR },
              }}
            >
              Terms of Use
            </Link>
          </Box>

          <Divider sx={{ borderColor: BORDER_COLOR, my: 3 }} />

          {/* Version & Copyright */}
          <Box sx={{ textAlign: 'center' }}>
            <Typography
              variant="caption"
              sx={{ color: 'rgba(255,255,255,0.5)', display: 'block', mb: 0.5 }}
            >
              Preview v0.1.0
            </Typography>
            <Typography
              variant="caption"
              sx={{ color: 'rgba(255,255,255,0.35)', display: 'block', mb: 0.5 }}
            >
              Developed at Pineview in Oslo, Norway. Free access during the preview.
            </Typography>
            <Typography
              variant="caption"
              sx={{ color: 'rgba(255,255,255,0.35)', display: 'block' }}
            >
              © 2026 Pine View Software AS. All Rights Reserved.
            </Typography>
          </Box>
        </Box>
      </Paper>
    </Box>
  );
}
